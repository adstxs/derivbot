# Deriv Auto Trade Bot: Node.js 

